// GITI inlined in Engineered
